package Product;

import java.util.Collection;

public interface ProductDAO {
	
	Collection<Product> getAll();
	Product getById(int id);
	String addProduct(Product product);
	String updateProduct(Product product);
	String deleteProduct(int id);
	
	

}
