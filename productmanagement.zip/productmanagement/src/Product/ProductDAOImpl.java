package Product;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public class ProductDAOImpl implements ProductDAO {
	
	
	private static Map<Integer,Product> proDb=new HashMap<>();
	
	
	

	public ProductDAOImpl() {
		
		proDb.put(1, new Product(1,"bike","faster",23,70000));
		proDb.put(2, new Product(2,"laptop","beast",22,50000));
		proDb.put(3, new Product(3,"mobile","best",33,40000));
		proDb.put(4, new Product(4,"tv","good",22,30000));
	}
	

	@Override
	public Collection<Product> getAll() {
		// TODO Auto-generated method stub
		return proDb.values();
	}

	@Override
	public Product getById(int id) {
		Product emp=proDb.get(id);
		if(emp==null) {
			throw new ProductManagementException("Product with id "+id+" does not exist");
		}
		return emp;
	}

	@Override
	public String addProduct(Product product) {
		// TODO Auto-generated method stub
	    proDb.put(product.getId(), product);
		return "Product with Id "+product.getId()+" added successfully";
	}

	@Override
	public String updateProduct(Product product) {
		// TODO Auto-generated method stub
		Product emp=proDb.get(product.getId());
		emp.setName(product.getName());
		emp.setDescription(product.getDescription());
		emp.setQuantityinhand(product.getQuantityinhand());
		emp.setPrice(product.getPrice());
		
		
		
		
		return "Product with Id "+product.getId()+" updated successfully";
	}

	@Override
	public String deleteProduct(int id) {
		// TODO Auto-generated method stub
		proDb.remove(id);
		
		return "Product with id "+id+" deleted successfully";
	}

}


