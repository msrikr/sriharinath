package Product;

public class ProductManagementException extends RuntimeException {

	public ProductManagementException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductManagementException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
