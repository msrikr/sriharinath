package Product;

import java.util.Scanner;


public class Main {
	
	private static Scanner sc=new Scanner(System.in);
	private static ProductManagementService proService=new ServiceImpl();

	public static void main(String[] args) {
		
		int choice=0;
		
		while(true) {
			System.out.println("Select your choice:");
			System.out.println("==================");
			
			System.out.println("1. Show All Products:");
			System.out.println("2. Find Products By Id:");
			System.out.println("3. Add Product:");
			System.out.println("4. Update Product:");
			System.out.println("5. Delete Product:");
			
			System.out.println("6. Exit");
			System.out.println("Enter your choice:");
			choice=sc.nextInt();
			switch (choice) {
			case 1: 
				
				var products=proService.getAll();
				for (Product product :products ) {
					System.out.println(product);
				}
				System.out.println();
				
				break;
				case 2:
					try {
						System.out.println("Enter the Product Id");
						int id=sc.nextInt();
						var product=proService.getById(id);
						System.out.println(product);
						System.out.println();
					}
					catch(ProductManagementException ex) {
						System.out.println(ex.getMessage());
					}
					
					break;
				case 3:
					addProduct();
					break;
				case 4:
					updateProduct();
					break;
				case 5:
					deleteProduct();
					break;
					
				case 6:
					System.exit(0);
					
					
				
			
			default:
				System.out.println("Invalid option, please try again");
			}
			
			
			
			
		}
		
		
	}
	private static void addProduct() {
		Product product=new Product();
		System.out.println("Enter Product Id");
		product.setId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Name");
		product.setName(sc.nextLine());
		
		System.out.println("Enter Description");
		product.setDescription(sc.nextLine());
		System.out.println("Enter quantityinhand");
		product.setQuantityinhand(sc.nextInt());
		System.out.println("Enter price");
		product.setPrice(sc.nextInt());
		
		String result=proService.addProduct(product);
		System.out.println(result);
		System.out.println();
		
		
	}
	private static void updateProduct() {
		Product product=new Product();
		System.out.println("Enter Product Id");
		product.setId(sc.nextInt());
		sc.nextLine();
		System.out.println("Enter Name");
		product.setName(sc.nextLine());
		
		System.out.println("Enter Description");
		product.setDescription(sc.nextLine());
		System.out.println("Enter Quantityinhand");
		product.setQuantityinhand(sc.nextInt());
		System.out.println("Enter Price");
		product.setPrice(sc.nextDouble());
		
		String result=proService.updateProduct(product);
		System.out.println(result);
		System.out.println();
		
		
	}
	
	private static void deleteProduct() {
		System.out.println("Enter Product Id");
		int id=sc.nextInt();
		String result=proService.deleteProduct(id);
		System.out.println(result);
		System.out.println();
	}

}
