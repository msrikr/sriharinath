package Product;

import java.util.Collection;

public interface ProductManagementService {

	Collection<Product> getAll();
	Product getById(int id);
	String addProduct(Product product);
	String updateProduct(Product product);
	String deleteProduct(int id);
}

