package junit;

//DateTest.java

import org.junit.Test;
import static org.junit.Assert.*;

public class DateTest {

 @Test
 public void testConstructorAndGetters() {
     Date date = new Date(10, 6, 2024);

     assertEquals(10, date.getDay());
     assertEquals(6, date.getMonth());
     assertEquals(2024, date.getYear());
 }

 @Test
 public void testSettersAndGetters() {
     Date date = new Date(1, 1, 2000);

     date.setDay(15);
     assertEquals(15, date.getDay());

     date.setMonth(12);
     assertEquals(12, date.getMonth());

     date.setYear(2023);
     assertEquals(2023, date.getYear());
 }

 @Test
 public void testToString() {
     Date date = new Date(31, 12, 2023);
     String expected = "Date is 31/12/2023";
     
     assertEquals(expected, date.toString());
 }
}

