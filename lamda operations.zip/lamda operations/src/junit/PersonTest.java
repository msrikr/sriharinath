package junit;

import static org.junit.jupiter.api.Assertions.*;
import junit.Person;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

class PersonTest {

	@Test
    public void testConstructorValidNames() {
        Person person = new Person();
        assertEquals("Srihari", person.getFirstName());
        assertEquals("nath", person.getLastName());
        assertEquals("Srihari nath", person.getFullName());
    }

    @Test
    public void testGetFirstName() {
        Person person = new Person();
        assertEquals("Srihari", person.getFirstName());
    }

    @Test
    public void testGetLastName() {
        Person person = new Person();
        assertEquals("nath", person.getLastName());
    }
   
}

