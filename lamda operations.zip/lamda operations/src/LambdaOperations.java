
import java.util.Scanner;

@FunctionalInterface
interface StringOperation {
    String operate(String s);
}

public class LambdaOperations {

   
    public static String applyOperation(String s, StringOperation operation) {
        return operation.operate(s);
    }
 
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        StringOperation reverseOperation = (String s) -> {
            StringBuilder reversed = new StringBuilder(s);
            return reversed.reverse().toString();
        };

      
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();

       
        String reversedString = applyOperation(input, reverseOperation);

        System.out.println("Original String: " + input);
        System.out.println("Reversed String: " + reversedString);

        scanner.close();
    }
}

