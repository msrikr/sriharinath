import java.rmi.server.Operation;

@FunctionalInterface
interface ArithmeticOperation {
    double operate(double a, double b);
}

public class Arthemetic {
    public static void main(String[] args) {
       
        performOperation(5, 3, (a, b) -> a + b);

       
        performOperation(5, 3, (a, b) -> a - b);

       
        performOperation(5, 3, (a, b) -> a * b);

       
        performOperation(10, 2, (a, b) -> a / b);
    }

    
    public static void performOperation(double a, double b, ArithmeticOperation operation) {
        double result = operation.operate(a, b);
        char operator;

        
        if (operation instanceof AdditionOperation) {
            operator = '+';
        } else if (operation instanceof SubtractionOperation) {
            operator = '-';
        } else if (operation instanceof MultiplicationOperation) {
            operator = '*';
        } else if (operation instanceof DivisionOperation) {
            operator = '/';
        } else {
            operator = '?';
        }

        System.out.printf("%.2f %c %.2f = %.2f\n", a, operator, b, result);
    }
}
