

import java.time.LocalDate;
import java.time.Period;

public class Employee {

    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private String phoneNumber;
    private LocalDate hireDate;
    private String designation;
    private double salary;
    private int managerId;
    private String department;

    public Employee(int id, String firstName, String lastName, String email, String phoneNumber, LocalDate hireDate,
            String designation, double salary, int managerId, String department) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.phoneNumber = phoneNumber;
        this.hireDate = hireDate;
        this.designation = designation;
        this.salary = salary;
        this.managerId = managerId;
        this.department = department;
    }

    
    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public LocalDate getHireDate() {
        return hireDate;
    }

    public String getDesignation() {
        return designation;
    }

    public double getSalary() {
        return salary;
    }

    public int getManagerId() {
        return managerId;
    }

    public String getDepartment() {
        return department;
    }

    
    public Period serviceDuration() {
        LocalDate currentDate = LocalDate.now();
        return Period.between(hireDate, currentDate);
    }

    
    public static Period durationBetween(LocalDate startDate, LocalDate endDate) {
        return Period.between(startDate, endDate);
    }

    
    public LocalDate warrantyExpirationDate(int months, int years) {
        return hireDate.plusMonths(months).plusYears(years);
    }


	@Override
	public String toString() {
		return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", email=" + email
				+ ", phoneNumber=" + phoneNumber + ", hireDate=" + hireDate + ", designation=" + designation
				+ ", salary=" + salary + ", managerId=" + managerId + ", department=" + department + "]";
	}
    


}

