
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Main {

    public static void main(String[] args) {
       
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(1, "Srihari", "Nath", "srihari.nath@example.com", "1234567890", LocalDate.of(2020, 5, 15), "Manager", 50000, 0, "HR"));
        employees.add(new Employee(2, "Srikanth", "kumar", "srikanth.kumar@example.com", "9876543210", LocalDate.of(2019, 8, 20), "Developer", 60000, 1, "IT"));
        employees.add(new Employee(3, "Prabhu", "Teja", "prabhu.teja@example.com", "5678901234", LocalDate.of(2018, 10, 10), "Analyst", 45000, 1, null));
        employees.add(new Employee(4, "Bharat", "kumar", "bharat.kumar@example.com", "3456789012", LocalDate.of(2017, 3, 25), "Tester", 55000, 2, "IT"));
        employees.add(new Employee(5, "Praveen", "Kumar", "praveen.kumar@example.com", "7890123456", LocalDate.of(2016, 12, 1), "Manager", 70000, 0, "HR"));

       
        double totalSalary = employees.stream()
                .mapToDouble(Employee::getSalary)
                .sum();
        System.out.println("Total salary of all employees: " + totalSalary);

     
        Employee seniorMostEmployee = employees.stream()
                .min((e1, e2) -> e1.getHireDate().compareTo(e2.getHireDate()))
                .orElse(null);
        System.out.println("Senior most employee: " + seniorMostEmployee);

        
        System.out.println("Employee name and duration of service:");
        employees.forEach(e -> {
            Period servicePeriod = e.serviceDuration();
            System.out.println(e.getFirstName() + " " + e.getLastName() +
                    " - " + servicePeriod.getYears() + " years, " +
                    servicePeriod.getMonths() + " months, " +
                    servicePeriod.getDays() + " days");
        });

        
        List<Employee> employeesWithoutDepartment = employees.stream()
                .filter(e -> e.getDepartment() == null)
                .collect(Collectors.toList());
        System.out.println("Employees without department:");
        employeesWithoutDepartment.forEach(System.out::println);

       
        System.out.println("Employee name, hire date and day of week:");
        employees.forEach(e -> {
            DayOfWeek dayOfWeek = e.getHireDate().getDayOfWeek();
            System.out.println(e.getFirstName() + " " + e.getLastName() +
                    " - Hire Date: " + e.getHireDate() +
                    ", Day of Week: " + dayOfWeek);
        });

       
        System.out.println("Employee name, salary and salary increased by 15%:");
        employees.forEach(e -> {
            double increasedSalary = e.getSalary() * 1.15;
            System.out.println(e.getFirstName() + " " + e.getLastName() +
                    " - Salary: " + e.getSalary() +
                    ", Increased Salary: " + increasedSalary);
        });

      
        List<Employee> employeesWithoutManager = employees.stream()
                .filter(e -> e.getManagerId() == 0)
                .collect(Collectors.toList());
        System.out.println("Employees without manager:");
        employeesWithoutManager.forEach(System.out::println);

        
        LocalDate purchaseDate = LocalDate.of(2023, 6, 1);
        int warrantyMonths = 12;
        int warrantyYears = 2;

        LocalDate warrantyExpirationDate = employees.get(0).warrantyExpirationDate(warrantyMonths, warrantyYears);
        System.out.println("Warranty expiration date for product purchased on " + purchaseDate + " is " + warrantyExpirationDate);
    }
}
