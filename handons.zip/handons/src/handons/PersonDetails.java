package handons;

import java.util.Scanner;

public class PersonDetails {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter Person Details:");
        System.out.print("First Name: ");
        String name1 = scanner.nextLine();
        
        System.out.print("Last Name: ");
        String name2 = scanner.nextLine();
        
        System.out.print("Gender (M/F/Other): ");
        String gender = scanner.nextLine();

        System.out.print("Age: ");
        int age = scanner.nextInt();
        
        System.out.print("weight: ");
        int weight = scanner.nextInt();
        scanner.nextLine(); 

        System.out.println("\nPerson Details:");
        System.out.println("================");
        System.out.println("First Name: " + name1);
        System.out.println("Last Name: " + name2);
        System.out.println("Age: " + age);
        System.out.println("Gender: " + gender);
        System.out.println("weight:" + weight);

        scanner.close();
    }
}

