package handons;
class Employee {
    
    private int id;
    private String name;
    private String gender;
    private int age;
    private double salary;
    private String designation;
    private String insuranceScheme;

   
    public Employee(int id, String name, String gender, int age, double salary, String designation) {
        this.id = id;
        this.name = name;
        this.gender = gender;
        this.age = age;
        this.salary = salary;
        this.designation = designation;
        this.insuranceScheme = determineInsuranceScheme();
    }

  
    private String determineInsuranceScheme() {
        if (salary > 5000 && salary < 20000 && designation.equals("System Associate")) {
            return "Scheme C";
        } else if (salary >= 20000 && salary < 40000 && designation.equals("Programmer")) {
            return "Scheme B";
        } else if (salary >= 40000 && designation.equals("Manager")) {
            return "Scheme A";
        } else if (salary < 5000 && designation.equals("Clerk")) {
            return "No Scheme";
        } else {
            return "No Scheme";
        }
    }

  
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getGender() {
        return gender;
    }

    public int getAge() {
        return age;
    }

    public double getSalary() {
        return salary;
    }

    public String getDesignation() {
        return designation;
    }

    public String getInsuranceScheme() {
        return insuranceScheme;
    }

 
    public void displayEmployeeDetails() {
        System.out.println("ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Gender: " + gender);
        System.out.println("Age: " + age);
        System.out.println("Salary: " + salary);
        System.out.println("Designation: " + designation);
        System.out.println("Insurance Scheme: " + insuranceScheme);
    }
}


